#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int count = 0;  //目前还没解决这个全局变量。。

//-------------------------------------------------------------------------------------------
struct user{
        int        id;
        char   name[10];
        int       age;
        int    money;     
    };
struct user users[20];


//--------------------------------------------------------------------------------------------
int input_main();  //主界面
int add_user();   // 添加用户
int show_users();  //显示所有用户
int show_user();   // 显示某用户
int update_user(); //更改用户
int delete_user();  // 删除用户

//---------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------
int add_user()
{    
    // *pa = 0;
    // int countp =*pa;
    // int countp = 0;
    int add_choice = 0;
    while(1){
        users[count].id=count;
        users[count].age=0;
        users[count].money=0;
        printf("请输入用户名：\n");
        scanf("%s", users[count].name);
        printf("请输入年龄：\n");
        scanf("%d", &users[count].age);
        printf("请输入账户余额：\n");
        scanf("%d", &users[count].money);
        printf("用户 %s 添加成功\n", users[count].name);
        count++;
        printf("是否继续输入？是 (1)否(2)\n");
        scanf("%d",&add_choice);
        if(add_choice==1) continue;
        if(add_choice==2) break;
        if(add_choice!=1&&add_choice!=2){ 
            while(1){
            printf("输入错误，请重新输入\n");
            scanf("%d",&add_choice);
            if(add_choice==1||add_choice==2) break;
               }
            }
        if(add_choice==2) break;
    }
    // return  countp;

}
//------------------------------------------------------------------------------------------------


int show_users()
{    
    // int count = *pb;
    for(int i=0;i<count;i++){
        printf("用户id:%d\t", users[i].id);
        printf("用户名:%s\t  ", users[i].name);
        printf("年龄:%d\t  ", users[i].age);
        printf("账户余额:%d \t \n", users[i].money);
        
     }
      input_main();
}
//----------------------------------------------------------------------------------------
int show_user()
{   
    int tempid;
     printf("请输入你要查询的用户id\n");
     scanf("%d",&tempid );
     int i,j;
     int mdzz=0;
     for(i=0;i<count;i++){
         if(tempid == users[i].id){
                      mdzz = 1;
                      j=i;
               }
     }
     if(mdzz==1){
         printf("用户名：%s\t年龄：%d\t账户余额：%d\t\n",users[j].name,users[j].age,users[j].money);
     }else{
          printf("用户不存在");
     }
}
//-----------------------------------------------------------------------------------------------
int update_user()
{
    int update_num;
    int update_choice;
     printf("请输入你要更改的用户id\n");
     scanf("%d",&update_num);
    printf("用户id:%d\t", users[update_num].id);
    printf("用户名:%s\t  ", users[update_num].name);
    printf("年龄:%d\t  ", users[update_num].age);
    printf("账户余额:%d \t \n", users[update_num].money);
     printf("请输入你要更改的项目:1.用户名\t2年龄\t3账户余额\t\n");
     scanf("%d",&update_choice);
     switch(update_choice){
        case 1:
            printf("请输入你要更改的数值:");
            scanf("%s",users[update_num].name);
            break;
        case 2:
            printf("请输入你要更改的数值:");
            scanf("%d",&users[update_num].age);
            break;
        case 3:
            printf("请输入你要更改的数值:");
            scanf("%d",&users[update_num].money);
            break;
        default:
             printf("输入错误，请重新输入！");       
     }
     input_main();
}
//-------------------------------------------------------------------------------------------------------------
int delete_user()  //有bug
{
    printf("请输入你要删除的用户id\n");
    int choice = 999;
    scanf("%d",&choice);
    for(int i = 0;i < count - 1;i++){
        if(choice - 1 + i <= count - 1 && choice + i <= count - 1){
        users[choice -1 + i] =users[choice + i ];
        }
    }
    printf("删除成功！\n");
}
//-------------------------------------------------------------------------------------------------------------
int input_main(){
    int choice = 0;
    printf("\t\t\t请选择你的操作\n");
    scanf("%d",&choice);
    if(choice<7 && choice>0){
        switch(choice){
            case 1 :
               add_user();
                break;
            case 2 :
                show_user();
                break;
            case 3 :
                 show_users();
                break;
            case 4 :
                update_user();
                break;
            case 5 :
                delete_user();
                break;
            case 6 :
                return 1;
        }
    }else{
        printf("\t\t\t没有这个操作，滚回去重来\n");
        input_main();
    }
} 
//--------------------------------------------------------------------------------------------------------------------
int main()
{   
     while(1){ 
        printf("\t\t\t| ***～欢迎来到全球最大的同性交友网站～***|\n");
        printf("\t\t\t|-----------------------------------------|\n");
        printf("\t\t\t|1.加入新会员                             |\n");
        printf("\t\t\t|2.查看某会员信息                         |\n");
        printf("\t\t\t|3.查看当前所有会员信息                   |\n");
        printf("\t\t\t|4.更改会员信息                           |\n");
        printf("\t\t\t|5.删除会员信息跑路                       |\n");
        printf("\t\t\t|6.我要退出啊啊啊                         |\n");
        printf("\t\t\t| ***   GitHub :  All Right Reserved   ***|\n");
        input_main();
        if(input_main()==1) break;
     }
}    




